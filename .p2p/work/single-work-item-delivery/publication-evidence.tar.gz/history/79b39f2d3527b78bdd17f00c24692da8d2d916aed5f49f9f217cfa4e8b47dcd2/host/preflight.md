# Delivery preflight: BLOCKED

Issue: https://github.com/grove/promise-to-proof/issues/28
Work item: work/single-work-item-delivery.md
Contract: imported source only; no planned revision or approved agreement.
Repository: /Users/grove/projects/promise-to-proof
Branch: main
Starting commit: 1a296f6ec7a064b32ce1be6a5d29f0c39df12294
Initial git status --short: empty; no tracked or untracked changes.
Candidate: not captured. Comparison base: not selected for review.

## Host invocation and completion

Invoked collaboration.spawn_agent with task_name=host_probe, fork_turns=none.
Host returned distinct agent identity /root/host_probe.
Requested harmless read-only AGENTS.md and git rev-parse HEAD inspection,
inspection of sandbox capabilities, no mutations, and no nested processes.
Completion received as FINAL_ANSWER from /root/host_probe.
The agent read AGENTS.md and observed the starting commit above, exit 0.
No separate session UUID was exposed. The host-issued agent path identifies this invocation.

The agent reported writable roots /Users/grove/projects/promise-to-proof,
/private/tmp, and /private/var/folders/vq/593qxcm57l90w1dlpywl_7nw0000gn/T.
The collaboration tool exposes no sandbox or filesystem permission parameter.
Separate context execution succeeded; filesystem-enforced read-only verification
against inputs in the shared workspace is unavailable through this launch API.
Read-only instructions alone do not establish the required boundary.
No product write was attempted by the probe. No review or proof ran.

## Blocker

The installed deliver-issue skill requires: "The workspace sandbox must keep
candidate inputs read-only." It also requires direct host tools when available,
and prohibits starting a nested CLI merely to obtain isolation.
The current host launch API cannot select that boundary. Stop before implementation.
This is a host capability gap, not a GitHub permission or automatic approval rejection.

## Saved inputs and checks

GitHub read succeeded with explicit user authority for gh outside the sandbox.
Issue body, labels, update timestamp and empty comments retained in evidence/issue-28-source.json.
Local source specification digest checked against the issue's pinned digest.
Filesystem helper created the imported work item and saved durable artifacts.
The enclosing workflow reread all saved bytes and checked their hashes.
No implementation, acceptance tests, candidate capture, review, proof, commit,
push, tracker write, or publication occurred.

## Next steps

1. Resume deliver-issue with work/single-work-item-delivery.md on a host that
   enforces read-only candidate, base, and agreement inputs for independent stages.
   Repeat preflight, then invoke plan-acceptance on the retained source before implementation.

Imported work item SHA-256: cb61afbf2dc2a8cf741edfe0180eb1ece208b721eb8d788dfeffbd34d91abf7a
