# Enforce single-work-item delivery on one supported host

Source: [GitHub issue #28](https://github.com/grove/promise-to-proof/issues/28)
Source: [Pinned specification](../plans/promise_to_proof_optimization_handoff.md)

Status: imported source only; not a planned or approved acceptance contract.
No contract revision assigned. Delivery stopped at host capability preflight.

## Imported source

Build the smallest controller that enforces Phase 2 delivery rules for one work item on one supported host.

Depend on the Phase 1 model delivered through #24. Reuse its documented limits and the existing contract, filesystem, and identity checks.

## Scope

Deliver in this order:

1. Choose and name the host. Demonstrate separate agent runs, protected code during verification, and host-issued run identities. Record unsupported capabilities.
2. Demonstrate an ordinary successful delivery. Require full independent review and proof, with saved, reread, retrievable reports and evidence for the exact current contract and candidate, including the correct review comparison base.
3. Handle failures and restarts. Preserve unfinished and unrelated work, reject late or stale reports, reconcile uncertain effects before retrying, and retain the one-repair allowance across restarts of the same invocation.
4. Record stage starts, finishes, failures, elapsed time, and available usage costs. Check approved limits before dispatching further work. Mark unavailable costs as unknown and distinguish measured spending from enforceable spending limits.

Keep the current full REVIEWED and PROVEN requirements. A changed candidate requires fresh full review and proof. Enforce authorization before actions occur.

## Completion evidence

Tests on the chosen host must demonstrate successful delivery and rejection of changed code, missing evidence, unauthorized actions, and a second repair after restart.

An interrupted handoff must resume safely or report the exact recovery blocker. Unrelated work must remain intact. Distinguish fixture results from evidence of real host isolation and provenance.

## Decisions and boundaries

Before implementation, name the host and establish which controls it can enforce. Use Section 24 to prepare the first concrete acceptance contract in work/. The source specification remains authoritative.

This issue covers Phase 2 only. Model-to-controller conformance testing, strategy comparisons, optional checking levels, child-task scheduling, and automatic strategy selection belong to later phases. Do not add support for multiple hosts or weaken existing acceptance rules. Publication remains separately authorized.

## Source

[Exact optimization handoff](https://github.com/grove/promise-to-proof/blob/1a296f6ec7a064b32ce1be6a5d29f0c39df12294/plans/promise_to_proof_optimization_handoff.md)

Selected scope: Section 19, Phase 2, with Sections 20–24 supplying planning guidance and applicable constraints.

- Repository: grove/promise-to-proof
- Path: plans/promise_to_proof_optimization_handoff.md
- Commit: 1a296f6ec7a064b32ce1be6a5d29f0c39df12294
- SHA-256: 7162a965fa53322a8805582756ea6137a847d72798e057dd751cc2e46c98f65a

The pinned GitHub file was retrieved and matched the local bytes.

<!-- grove:create-parent-issue source=grove/promise-to-proof:plans/promise_to_proof_optimization_handoff.md -->


## Amendments

No comments were returned by GitHub.
