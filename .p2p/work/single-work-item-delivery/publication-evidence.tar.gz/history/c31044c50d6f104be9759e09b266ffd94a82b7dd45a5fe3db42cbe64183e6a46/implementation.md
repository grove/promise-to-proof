# PARTIAL: single-work-item delivery

Contract: work/single-work-item-delivery.md v1, SHA-256 e447f13a94dae84b9af2dfc06cfb6be36900eee2c0e381a3942015245b48826d.
Scope: R1–R14, whole contract.
Candidate before: 1a296f6ec7a064b32ce1be6a5d29f0c39df12294.
Review base: 1a296f6ec7a064b32ce1be6a5d29f0c39df12294.
Candidate after: snapshot:sha256:847704b1ef38871fc2e62529426105cc31ae029a79c11e8190c00fcb3b519259, recoverable manifest in candidate.json. Product bytes are frozen.
Changes: one stdlib delivery controller, atomic replacement in the existing filesystem helper, deterministic failure checks, real-host check, and CLI documentation. Source checkout delivery preserves local work and reports an isolated recoverable candidate. No delivery commits, pushes, or publication.

## Requirement handoff

| ID | Implementation | Direct check and current observation | Remaining gap |
|---|---|---|---|
| R1 | Fresh exec command and host receipt parsing | Prior host probes plus development tiny run have distinct host thread IDs and process completion records. | Final fixed-candidate live run pending. |
| R2 | Scratch-only verifier cwd, external Git metadata, preflight probes | Development live preflights denied absolute, symlink and subprocess writes; scratch succeeded. | Final probes include source index and retained base content. |
| R3 | Sequential implementation, review, proof and completion gate | Development live implementation and review passed; proof running. | Final full live delivery pending. |
| R4 | Existing helper capture/validate/bindings; base bundle; report input equality | Fixture tests reconstruct content and reject candidate drift; final expanded reconstruction test pending. | Final check result pending. |
| R5 | Atomic helper save/history/readback; exact host report bytes; bundle checks | Fixture completion and evidence corruption tests pass; expanded storage failure checks pending. | Final check result pending. |
| R6 | Current source/candidate checks and attempt identity comparison | Stale return and candidate-drift fixture tests pass; repaired candidates rerun both verifiers. | Final suite pending. |
| R7 | Exclusive lock, saved reservation, protected launch/exit records | Fresh-process known completion reconciles once; missing completion blocks without redispatch. | Final suite pending. |
| R8 | Repair reservation before launch and immutable invocation | Successful and exhausted repair fixtures pass; repeated resume never grants another repair. | Final suite pending. |
| R9 | Isolated workspace and explicit exclusions with comparison-base bytes | Source byte/mode/symlink preservation and contested path tests pass. | Final suite pending. |
| R10 | Explicit local authority; isolated config; protected source/Git/controller inputs | Numeric socket denied in real host probe; connector/MCP/web tools disabled; fixture permission widening rejected. | Final source-Git and missing-authority checks pending. |
| R11 | Attempt start/finish/elapsed/host usage/unknown cost records | Successful, interrupted/failed and uncertain attempts retain available observations without fabricated costs. | Final suite pending. |
| R12 | Locked admission, persisted limits/deadline and repair use | Exhausted/expired limits and competing-controller tests pass; unsupported monetary cap blocks. | Final suite pending. |
| R13 | Result/host fields and CLI documentation | Fixture result separates enforced controls, measured host tokens, unknown cost and unsupported hard cap. | Final live comparison pending. |
| R14 | Full conjunction gate and structured BLOCKED result | Success/failure/restart fixtures pass with exact blocker and resume references. | Final live success pending. |

## Checks and limitations

- `python3 checks/test_p2p_delivery.py`: 19 tests passed in 99.110 seconds, retained output at evidence/fixture-tests-final.log.
- `python3 checks/test_p2p_filesystem.py`: 2 tests plus filesystem assertions passed after atomic replacement change.
- `python3 checks/test_verify_acceptance_bundle.py`: 2 tests passed.
- `git diff --check`: passed.
- Live development run: evidence/live-delivery-development-1. This run predates final code changes and is development evidence only. Real implementation completed, review returned REVIEWED, and proof returned PROVEN, but the review requirement row used `proven` instead of required `reviewed`. The completion gate rejected that inconsistent row with `review contains unresolved requirement findings`. This is retained as a failed run, not successful delivery.
- Frozen final live run: evidence/live-delivery-final, product key recorded in invocation.json. Running actual stages; no success claim yet.

## Next steps

1. Finish the frozen checks/check_p2p_delivery_host.py invocation.
2. Replace this progress report with the observed final live result; preserve any failure and frozen code for formal review/proof.
3. Hand off separately to /review-implementation work/single-work-item-delivery.md and /prove work/single-work-item-delivery.md.

Implementation report only; independent acceptance requires /prove.
