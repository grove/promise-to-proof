# PROVEN: work/tiny.md

Requirements: 1/1
Counterexamples tested: 1
Contract: `work/tiny.md`, revision v1
Contract snapshot: exact work-item bytes, SHA-256 `5fd555eb8132a635c95dcdfb76e647d3b859b51a51539fbc38aeb067986a502a`; binding `spec.txt` SHA-256 `96bbc5690a5a4af0a7ecc91d4f9faf97034a5e420189d348f5bcdd2c81dc0ce6`
Parent context: none
Candidate: `snapshot:sha256:fba8e34f9fa4246ccea677efe630aab66d24c62a93677534dbb15ce23ed362ff`; manifest digest recomputed and matched, all four manifest entries matched workspace bytes
Comparison base: `389cdd9d6e0b2f145432cca28388044943afa45d`
Candidate stability: unchanged across proof; final product status and manifest recheck matched initial observations
Contract stability: unchanged; work-item and binding-source hashes matched before and after verification
Verification context: fixed workspace `/Users/grove/projects/promise-to-proof/.p2p/work/single-work-item-delivery/evidence/live-delivery-development-1/tiny-source/.p2p/work/tiny/runtime/workspace`; command `python3 greet.py`; `TMPDIR` and `PYTHONPYCACHEPREFIX` pointed into the writable scratch directory. No product files or Git metadata were changed.

## Outcome

The contract’s intended outcome is that `greet.py` prints `hello` followed by a newline and exits zero. Running the agreed public seam produced exactly those bytes and exit status. The observed candidate snapshot and contract identities matched the supplied identities, and the candidate remained stable. R1 is proven.

## Requirement verdicts

| ID | Observation and oracle | Evidence reference | Verdict |
|---|---|---|---|
| R1 | Oracle: `spec.txt` requires a CLI to print hello followed by a newline and exit zero; `work/tiny.md` specifies the same exact output and status. Ran `python3 greet.py` in the fixed workspace. Actual stdout was `b'hello\\n'` (hex `68656c6c6f0a`), stderr was empty, and return code was 0. Assertions for exact `hello` plus newline and zero exit both passed. | Scratch artifact `r1-run.json` (SHA-256 `ba998f222083c53c4e53f5077dd154b21ffaa793c9c0041ddaf9ec50ba12af84`); command: `python3 greet.py`; environment and actual output are recorded in the artifact and reproduced here. | proven |

## Unresolved gaps

None affecting R1. The installed protocol links to `references/acceptance-bundle-v1.md`, but that file is absent from the installed skill package; the available acceptance-contract protocol and filesystem helper were read, and the missing bundle reference did not prevent this proof.

## Repairs needed

None.

Next steps:

1. `/review-implementation .p2p/work/tiny/candidate.json against 389cdd9d6e0b2f145432cca28388044943afa45d` (review is not present in the inspected handoff).