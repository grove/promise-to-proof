# PROVEN: tiny

Requirements: 1/1  
Counterexamples tested: 1  
Contract: `work/tiny.md`, revision v1  
Contract snapshot: exact contract bytes SHA-256 `5fd555eb8132a635c95dcdfb76e647d3b859b51a51539fbc38aeb067986a502a`  
Parent context: none  
Candidate: `snapshot:sha256:fba8e34f9fa4246ccea677efe630aab66d24c62a93677534dbb15ce23ed362ff`  
Candidate stability: unchanged; the filesystem validator confirmed the snapshot before and after the behavioral check  
Contract stability: unchanged  
Verification context: fixed workspace; Darwin, Python 3.9.6; `TMPDIR` and `PYTHONPYCACHEPREFIX` set to the authorized scratch directory.

## Outcome

The contract’s source, `spec.txt`, says the CLI prints `hello` followed by a newline and exits zero. The sole requirement expresses the same outcome, with wrong text or failure as counterexamples. The candidate identity, work-item hash, comparison base, and binding-input hash match the requested inputs. The filesystem validator recomputed the requested snapshot key from the retained manifest. Running the public seam produced exactly `hello\n` on stdout, empty stderr, and exit status 0; both required assertions passed. No contract discrepancy or unresolved gap remains.

## Requirement verdicts

| ID | Observation and oracle | Evidence reference | Verdict |
|---|---|---|---|
| R1 | The specified public seam produced exact stdout `hello\n` and exited with status 0. The independent oracle is the contract and binding specification: `hello` plus newline and exit zero. | Behavioral run: `python3 -c 'import subprocess,sys; r=subprocess.run([sys.executable,"greet.py"],capture_output=True); expected=b"hello\\n"; print("command: python3 greet.py"); print("stdout:",repr(r.stdout)); print("stderr:",repr(r.stderr)); print("exit_status:",r.returncode); assert r.stdout == expected, f"expected {expected!r}, got {r.stdout!r}"; assert r.returncode == 0, f"expected exit 0, got {r.returncode}"; print("assertion: exact stdout and zero exit status PASS")'`. Actual output: `command: python3 greet.py`; `stdout: b'hello\\n'`; `stderr: b''`; `exit_status: 0`; `assertion: exact stdout and zero exit status PASS`. Identity check: `python3 /Users/grove/.agents/skills/prove/scripts/p2p_filesystem.py --repo . validate --base 1da25ea3b570722d5fd0f0313b0619290713e32c work/tiny.md`; actual output confirmed candidate key `snapshot:sha256:fba8e34f9fa4246ccea677efe630aab66d24c62a93677534dbb15ce23ed362ff`, the requested work-item and binding hashes, and the comparison base. | proven |

## Unresolved gaps

- None

## Repairs needed

- None

Next steps:

1. `/review-implementation <candidate handoff> against 1da25ea3b570722d5fd0f0313b0619290713e32c`