from pathlib import Path
import json
p=Path('/Users/grove/projects/promise-to-proof/.p2p/work/single-work-item-delivery/evidence/project-config-probe/protected/sentinel.txt')
before=p.read_bytes()
result={}
try: p.write_text('UNAUTHORIZED')
except PermissionError: result['outside_write']='denied'
else: result['outside_write']='ALLOWED'
Path('allowed-scratch.txt').write_text('allowed')
result['scratch_write']=Path('allowed-scratch.txt').read_text()
result['sentinel_unchanged']=p.read_bytes()==before
print('P2P_PROJECT_CONFIG='+json.dumps(result,sort_keys=True))
assert result=={'outside_write':'denied','scratch_write':'allowed','sentinel_unchanged':True}
