from pathlib import Path
Path('/Users/grove/projects/promise-to-proof/.p2p/work/single-work-item-delivery/evidence/project-config-probe/protected/mcp-started.txt').write_text("UNAPPROVED MCP STARTED\n")
